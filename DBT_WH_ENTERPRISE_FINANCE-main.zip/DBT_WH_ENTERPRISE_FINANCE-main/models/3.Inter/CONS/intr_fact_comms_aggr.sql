{{ config(materialized="table", tags=["monthly"]) }}

with
    intr_fact_comms_aggr as (
        select
            case
                when a.dim_client_id is null then -1 else a.dim_client_id
            end dim_client_id,
            case
                when b.dim_product_type_id is null then -1 else b.dim_product_type_id
            end dim_product_type_id,
            case
                when c.dim_source_system_id is null then -1 else c.dim_source_system_id
            end dim_source_system_id,
            case
                when d.dim_business_unit_id is null then -1 else d.dim_business_unit_id
            end dim_business_unit_id,
            case when e.DIM_DATE_ID is null then -1 else e.DIM_DATE_ID end DIM_DATE_ID,
            min(z.ptfm_min_dt) as ptfm_min_dt,
            coalesce(sum(z.dcs_count_imp), 0.00) as dcs_count_imp,
            coalesce(sum(z.eob_count_prt), 0.00) as eob_count_prt,
            coalesce(sum(z.doc_elim_rate), 0.00) as doc_elim_rate
        from {{ ref("stg_comms_aggr") }} z
        left outer join
            {{ ref("dim_client") }} a on (z.srcuniqcd_dim_client = a.src_uniq_cd)
        left outer join
            {{ ref("dim_product_type") }} b
            on (z.srcuniqcd_dim_product_type = b.src_uniq_cd)
        left outer join
            {{ ref("dim_source_system") }} c
            on (z.srcuniqcd_dim_source_system = c.src_uniq_cd)
        left outer join
            {{ ref("dim_business_unit") }} d
            on (z.srcuniqcd_dim_business_unit = d.src_uniq_cd)
        left outer join
            {{ ref("dim_date") }} e
            on (z.tranyearmonthdate = e.dateday)
        group by
            a.dim_client_id,
            b.dim_product_type_id,
            c.dim_source_system_id,
            d.dim_business_unit_id,
            e.DIM_DATE_ID
    )
select
    dim_client_id,
    dim_product_type_id,
    dim_source_system_id,
    dim_business_unit_id,
    DIM_DATE_ID,
    ptfm_min_dt,
    dcs_count_imp,
    eob_count_prt,
    doc_elim_rate,
    concat(
        dim_client_id,
        '_',
        dim_product_type_id,
        '_',
        dim_source_system_id,
        '_',
        dim_business_unit_id,
        '_',
        DIM_DATE_ID
    ) as src_uniq_cd,
    getdate() as row_cre_dt,
    'SFAdmin' as row_cre_usr_id,
    getdate() as row_mod_dt,
    'SFAdmin' as row_mod_usr_id
from intr_fact_comms_aggr
